/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Demo2;
import Demo1.*;
/**
 *
 * @author pRIyA sONi
 */
public class B {
    public static void main(String[] args) {
        A obj=new A();
        obj.sum();
    }
}
