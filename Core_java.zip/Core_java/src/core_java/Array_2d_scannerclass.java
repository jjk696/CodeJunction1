/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core_java;
import java.util.Scanner;

public class Array_2d_scannerclass {
    public static void main(String[] args) {
        int a[][]=new int[3][3];
        Scanner obj=new Scanner(System.in);
        for(int i=0;i<=2;i++)
        {
            for(int j=0;j<=2;j++)
            {
                a[i][j]=obj.nextInt();
            }
            System.out.println(" ");
        } 
        for(int i=0;i<=2;i++)
        {
            for(int j=0;j<=2;j++)
            {
                System.out.print(" "+a[i][j]);
            }
            System.out.println(" ");
        }  
    }
}
