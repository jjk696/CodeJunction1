/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core_java;

import java.util.ArrayList;
import sun.security.util.ObjectIdentifier;


public class Array_list {
    public static void main(String[] args) {
        ArrayList al=new ArrayList();
        al.add("james");
        al.add(new Character('i'));
        al.add(new Integer(10));
        al.add(null);
        al.add("james");
        al.add(new Float(3.14f));
        System.out.println(al);
    }
   
}
