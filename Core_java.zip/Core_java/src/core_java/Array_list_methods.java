/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core_java;
import java.util.ArrayList;
public class Array_list_methods {
    public static void main(String[] args) {
       ArrayList al=new ArrayList();
        al.add("james");
        al.add("abc");
        al.add(new Character('i'));
        al.add(new Integer(10));
        al.add(null);
        al.add("james");
        al.add(new Float(3.14f));
        System.out.println(al);
        
        int a=al.size();
        System.out.println("size is "+a);
        boolean b=al.isEmpty();
        System.out.println("string is empty "+b);
        boolean c=al.contains("james");
        System.out.println("array list contains james "+c);
        int d=al.indexOf(10);
        System.out.println("index of 10 is "+d);
        int e=al.lastIndexOf("james");
        System.out.println("last index of james is "+e);
        boolean f=al.remove("i");
        System.out.println(f);  
    }
}