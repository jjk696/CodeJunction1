/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core_java;
import java.util.Scanner;

public class Array_scannerclass 
{
    public static void main(String[] args) {
        int a[]=new int[5];
         Scanner obj=new Scanner(System.in);
        for(int i=0;i<=a.length;i++)
        {
            a[i]=obj.nextInt();
            System.out.println(a[i]);
        }
    }
    
}
