/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core_java;

/**
 *
 * @author pRIyA sONi
 */
public class Count_is_instring {
    public static void main(String[] args) 
    {
     String S1="isss abc is xy isssis";
     int count=0;
     for(int j=0;j<S1.length();j++)
     {
        if(S1.charAt(j)=='i')
        {
            if(S1.charAt(j+1)=='s')
            {
            count=count+1;
            }
        }
      }    
     System.out.println("number of is are:" +count);
}
}