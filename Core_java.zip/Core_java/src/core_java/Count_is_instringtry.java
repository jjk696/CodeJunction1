/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core_java;

/**
 *
 * @author pRIyA sONi
 */
public class Count_is_instringtry 
{
    public static void main(String[] args) 
    {
     String S1="isss abc is xy is";
     int count=0;
     String S2="is";
     for(int i=0;i<S1.length();i++)
     {
      if(S1.charAt(i)==' ')
      {
       String a=S1.substring(i-2,i);
       if(a.equals(S2)==true)
       {
           count=count+1;
       }
       if(S1.lastIndexOf(' ')==i)
        {
          String b=S1.substring(i+1);
          if(b.equals(S2)==true)
         {
            count=count+1;
         }
        }
      }
    } 
        System.out.println("number of is are:" +count);
    }
}
