/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core_java;

import com.sun.org.apache.bcel.internal.generic.GOTO;
import com.sun.org.apache.bcel.internal.generic.GotoInstruction;
import java.util.concurrent.RecursiveTask;
import sun.org.mozilla.javascript.internal.ast.ContinueStatement;

/**
 *
 * @author pRIyA sONi
 */
public class Count_noloop 
{
    public static void main(String[] args)
    {
    count(1);
    }
    public static void count(int c)
    {       
    if(c<=10)
    {
        System.out.println(c);
        c++;   
        count(c);
    }
    }   
}
