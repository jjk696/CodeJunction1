/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core_java;
import java.awt.event.*;
import java.awt.*;
import javax.swing.*;

class DemoSwing extends JFrame implements ActionListener
{
	JLabel l1,l2;
	JTextField txt;
	JPasswordField pwt;
	JPanel p;
	JButton bt1,bt2,bt3;
DemoSwing()
{
	p=new JPanel();
        l1=new JLabel("Username");
	l2=new JLabel("Password");
	txt=new JTextField(10);
	pwt=new JPasswordField(5);
    bt1=new JButton("login");
    bt2=new JButton("cancel");
    bt3=new JButton("exit");	
	p.setLayout(null);
	l1.setBounds(25,15,100,25);
	txt.setBounds(150,15,100,25);
	l2.setBounds(25,50,100,25);
	pwt.setBounds(150,50,100,25);
	bt1.setBounds(25,100,100,25);
	bt2.setBounds(150,100,100,25);
	bt3.setBounds(280,100,100,25); 
	p.add(l1);
	p.add(l2);
	p.add(txt);
	p.add(pwt);
    p.add(bt1);
    p.add(bt2);
    p.add(bt3);
	add(p);
	
setVisible(true);
setSize(400,400);
setTitle("my first frame ");
setResizable(false);
setLocation(200,100);
}
public void actionPerformed(ActionEvent ae)
{
	
}
public static void main (String u[])
{
DemoSwing at=new DemoSwing();
}
}
