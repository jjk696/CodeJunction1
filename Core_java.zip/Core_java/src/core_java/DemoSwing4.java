/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core_java;
import java.awt.event.*;
import javax.swing.*;

class DemoSwing4 extends JFrame implements ActionListener
{
	JLabel l1,l2;
	JTextField txt;
	JPasswordField pwt;
	JPanel p;
	JButton bt1,bt2,bt3;
DemoSwing4()
{
	p=new JPanel();
    l1=new JLabel("Username");
	l2=new JLabel("Password");
	txt=new JTextField(10);
	pwt=new JPasswordField(5);

    bt1=new JButton("login");
    bt1.addActionListener(this);
    bt2=new JButton("cancel");
	bt2.addActionListener(this);
    bt3=new JButton("exit");	
    bt3.addActionListener(this);
	p.setLayout(null);
    l1.setBounds(25,15,100,25);
	txt.setBounds(150,15,100,25);
	l2.setBounds(25,50,100,25);
	pwt.setBounds(150,50,100,25);
	bt1.setBounds(25,100,100,25);
	bt2.setBounds(150,100,100,25);
	bt3.setBounds(280,100,100,25);  
	p.add(l1);
	p.add(l2);
	p.add(txt);
	p.add(pwt);
    p.add(bt1);
    p.add(bt2);
    p.add(bt3);
	add(p);
	
setVisible(true);
setSize(400,400);
setTitle("my  first frame ");
setResizable(false);
setLocation(200,100);
}
public void actionPerformed(ActionEvent e)
{
if(e.getSource()==bt1)
  {
  String user=txt.getText();
  String p=pwt.getText();
  if(user.equals("appin")&&p.equals("123"))
  {
    JOptionPane.showMessageDialog(this,"valid User","Authentication",1);
   new DemoSwing2().setVisible(true);
    setVisible(false); 
   
  } 
  else
  {
   JOptionPane.showMessageDialog(null,"invalid User","Error",2);
  }
}
 else if(e.getSource()==bt2)
{
txt.setText("");
pwt.setText("");
}
else
{
	
System.exit(0);
}
}
public static void main (String u[])
{
DemoSwing4 at=new DemoSwing4();
}
}