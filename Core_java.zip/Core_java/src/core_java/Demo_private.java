/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core_java;

/**
 *
 * @author pRIyA sONi
 */
public class Demo_private 
{
 private int a=5;    
}
class B extends Demo_private
{
    public static void main(String[] args) 
    {
     A obj=new A();
        System.out.println(obj.A);
    }
}
