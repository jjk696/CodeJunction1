/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core_java;

/**
 *
 * @author pRIyA sONi
 */
public class Demo_protected 
{
 protected void sum()
 {
     System.out.println("sum");
 }
}
class B extends Demo_protected
{
    void sum()
    {
        System.out.println("add");
    }
    public static void main(String[] args) {
        B obj= new B();
        obj.sum();
    }
} 
