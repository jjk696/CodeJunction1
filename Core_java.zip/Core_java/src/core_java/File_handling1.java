/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core_java;
import java.io.File;

public class File_handling1 
{
    public static void main(String[] args) {
        File f=new File("F:\\new");
        String s[]=f.list();
        File sFile[]=f.listFiles();
        for(int i=0;i<s.length;i++)
        {
            System.out.println("list "+s[i]);
            System.out.println("list file "+sFile[i]);
        }
    }
    
}
