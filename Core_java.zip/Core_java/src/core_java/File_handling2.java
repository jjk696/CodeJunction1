/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core_java;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
public class File_handling2 {
    public static void main(String[] args) {
        File newf=new File("F:/festivals/Demo");
        newf.mkdir();
        File new_ND=new File("F:/festivals/Demo/Java/Python");
        new_ND.mkdirs();
        File createFile=new File("F:/festivals/Demo/Java/Python/Demo.txt");
        try 
        {
            createFile.createNewFile();
        } 
        catch (IOException ex) 
        {
            Logger.getLogger(File_handling2.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
