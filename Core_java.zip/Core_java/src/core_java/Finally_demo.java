/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core_java;

/**
 *
 * @author pRIyA sONi
 */
public class Finally_demo 
{
    public static void main(String[] args) 
    {
     int a=5,b=0;
     try
     {
         int c=a/b;
     }
     finally
     {
         System.out.println("finally");
     }
        System.out.println("hello");
    } 
}
