/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core_java;
import java.awt.*;
public class Frame_demo extends Frame
{
    Label l;
    TextField txt;
    Panel p;
    Button bt;
    Checkbox cb1,cb2,cb3;
    List list;
    TextArea ta;

    Frame_demo() 
    {
    p=new Panel();
    l=new Label();
    txt=new TextField();
    bt=new Button("login");
    cb1=new Checkbox("C");
    cb2=new Checkbox("C++");
    cb3=new Checkbox("java");
    list=new List(5,true);
    ta=new TextArea(5,20);
    list.add("c");
    list.add("c++");
    list.add("java");
    list.add("python");
    list.add("android");
    
    p.add(l);
    p.add(txt);
    p.add(bt);
    p.add(cb1);
    p.add(cb2);
    p.add(cb3);
    p.add(list);
    p.add(txt);
    p.setBackground(Color.blue);
    add(p);
        setVisible(true);
        setSize(400,400);
        setTitle("my first frame");
        setLocation(200,100);
    }
    public static void main(String[] args) {
        Frame_demo obj=new Frame_demo();
    }
}