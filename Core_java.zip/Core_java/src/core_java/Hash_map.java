/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core_java;
import java.util.HashMap;
public class Hash_map {
    public static void main(String[] args) {
    HashMap hm=new HashMap();
    hm.put(1,"abc");
    hm.put(null,"xyz");
    hm.put(2,"xyz");
    hm.put(1,"lmn");
    hm.put(null,3);
    hm.put(4,null);
    System.out.println(hm);
    }
    
}
