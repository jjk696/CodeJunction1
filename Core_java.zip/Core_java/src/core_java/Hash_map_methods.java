/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core_java;
import java.util.HashMap;
public class Hash_map_methods {
    public static void main(String[] args) {
    HashMap hm=new HashMap();
    hm.put(1,"abc");
    hm.put(null,"xyz");
    hm.put(2,"xyz");
    hm.put(1,"lmn");
    hm.put(3,"efg");
    System.out.println(hm);
    
        int a=hm.size();
        System.out.println(a);
        int b=hm.hashCode();
        System.out.println(b);
        boolean c=hm.isEmpty();
        System.out.println(c);
        Object d=hm.get(1);
        System.out.println(d);
        boolean e=hm.containsKey(5);
        System.out.println(e);
        Object f=hm.put(4,"value");
        System.out.println(hm);
        Object g=hm.remove(null);
        System.out.println(hm);
        Object hm1=hm.clone();
        System.out.println(hm1); 
    }
}
