/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core_java;

import java.awt.*;
import javax.swing.*;
public class JFrame_Demo1 extends Frame
{
    JLabel l;
    JTextField txt;
    JPanel p;
    JButton bt;
    JCheckBox cb1,cb2,cb3;
    List list;
    JTextArea ta;
    JComboBox cbb;

    JFrame_Demo1() 
    {
    p=new JPanel();
    l=new JLabel();
    txt=new JTextField();
    bt=new JButton("login");
    cb1=new JCheckBox("C");
    cb2=new JCheckBox("C++");
    cb3=new JCheckBox("java");
    list=new List(5,true);
    ta=new JTextArea(5,20);
    cbb=new JComboBox();
    cbb.addItem("c");
    cbb.addItem("c++");
    cbb.addItem("python");
    
    list.add("c");
    list.add("c++");
    list.add("java");
    list.add("python");
    list.add("android");
    
    p.add(l);
    p.add(txt);
    p.add(bt);
    p.add(cb1);
    p.add(cb3);
    p.add(list);
    p.add(txt);
    p.add(cbb);
    p.setBackground(Color.blue);

    add(p);
    setVisible(true);
    setSize(400,400);
    setTitle("my first frame");
    setLocation(200,100);
    }
    public static void main(String[] args) {
        JFrame_Demo1 obj=new JFrame_Demo1();
    }
}
