/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core_java;
import java.awt.*;
import javax.swing.*;
public class JFrame_Menubar extends JFrame
{
JPanel p;
JMenuBar mbr;
JMenu m1,m2;
JMenuItem it1,it2,it3,it4,it5,it6;
JFrame_Menubar()
{
    p=new JPanel();
    mbr=new JMenuBar();
    m1=new JMenu("file");
    m2=new JMenu("edit");
    it1=new JMenuItem("new");
    it2=new JMenuItem("open");
    it3=new JMenuItem("save");
    it4=new JMenuItem("cut");
    it5=new JMenuItem("copy");
    it6=new JMenuItem("paste");
    
    setJMenuBar(mbr);
    mbr.add(m1);
    mbr.add(m2);
    m1.add(it1);
    m1.add(it2);
    m1.add(it3);
    m2.add(it4);
    m2.add(it5);
    m2.add(it6);
    
    p.add(mbr);
    p.add(m1);
    p.add(it1);
    p.add(it2);
    p.add(it3);
    p.add(m2);
    p.add(it4);
    p.add(it5);
    p.add(it6);
    
    add(p);
    setVisible(true);
    setSize(400,400);
    setTitle("my first frame");
    setLocation(200,100);
}
    public static void main(String[] args) {
    JFrame_Menubar obj=new JFrame_Menubar();
    }
}
