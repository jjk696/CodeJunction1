/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core_java;
import java.awt.*;
import javax.swing.*;
public class JFrame_borderlayout extends JFrame
{
   JPanel p;
   JButton bt1,bt2,bt3,bt4,bt5;
   JFrame_borderlayout()
   {
     p=new JPanel();
     bt1=new JButton("top");
     bt2=new JButton("bottom");
     bt3=new JButton("right");
     bt4=new JButton("left");
     bt5=new JButton("centre");
     
     p.setLayout(new BorderLayout());
     p.add(bt1,BorderLayout.NORTH);
     p.add(bt2,BorderLayout.SOUTH);
     p.add(bt3,BorderLayout.EAST);
     p.add(bt4,BorderLayout.WEST);
     p.add(bt5,BorderLayout.CENTER);
     add(p);
     setVisible(true);
    setSize(400,400);
    setTitle("my first frame");
    setLocation(200,100);
}
    public static void main(String[] args) {
    JFrame_borderlayout obj=new JFrame_borderlayout();
    }
   }