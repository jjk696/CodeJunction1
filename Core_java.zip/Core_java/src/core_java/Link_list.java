/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core_java;
import java.util.LinkedList;

public class Link_list {
    public static void main(String[] args) {
        LinkedList l=new LinkedList();
        l.add("james");
        l.add(new Character('i'));
        l.add(new Integer(10));
        l.add(null);
        l.add("james");
        l.add(new Float(3.14f));
        System.out.println(l);
    }
   
    }
