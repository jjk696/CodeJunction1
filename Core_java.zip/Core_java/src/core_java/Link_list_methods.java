/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core_java;
import java.util.LinkedList;
public class Link_list_methods {
    public static void main(String[] args) {
        LinkedList l=new LinkedList();
        l.add("james");
        l.add(new Character('i'));
        l.add(new Integer(10));
        l.add(null);
        l.add("james");
        l.add(new Float(3.14f));
        System.out.println(l);
        
        int a=l.size();
        System.out.println(a);
        Object b=l.getFirst();
        System.out.println(b);
        Object c=l.getLast();
        System.out.println(c);
        Object d=l.removeFirst();
        System.out.println(l);
        boolean e=l.contains(4);
        System.out.println(e);
        boolean f=l.add(3);
        System.out.println(l);
        Object g=l.get(4);
        System.out.println(g);
        Object h=l.set(6,'p');
        System.out.println(l);
        
    }
    
}
