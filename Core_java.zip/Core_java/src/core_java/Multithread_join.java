/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core_java;
public class Multithread_join extends Thread 
{
    public void run()
    {
        for(int i=1;i<=10;i++)
        {
            System.out.println("child thread");
        }
    }
}

class Demo2
{
    public static void main(String[] args) 
    {
      Multithread_join t1=new Multithread_join();
      try
      {
      t1.start();
      //t1.join();
      t1.join(5000);
      for(int i=1;i<=10;i++)
      {
          System.out.println("main thread");
      }
      }
      catch(Exception e)
       {
           System.out.println(e);       
       }
    }
}
