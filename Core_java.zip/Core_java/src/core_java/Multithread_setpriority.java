/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core_java;

public class Multithread_setpriority extends Thread
{    

}

class C
{
    public static void main(String[] args) 
    {
       System.out.println(Thread.currentThread().getPriority());
       Thread.currentThread().setPriority(7);  
        Multithread_setpriority t1=new Multithread_setpriority();
        System.out.println(t1.getPriority());
    }
}