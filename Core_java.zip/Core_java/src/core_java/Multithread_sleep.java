/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core_java;
public class Multithread_sleep 
{
    public static void main(String[] args) 
    {
     try
     {
     for(int i=1;i<=10;i++)
     {
         System.out.println("main thread");
         Thread.sleep(2000);
     }
     } 
     catch(Exception e)
     {
         System.out.println(e);
     }
    }
}
   
