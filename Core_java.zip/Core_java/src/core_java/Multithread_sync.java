/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core_java;

import java.util.logging.Level;
import java.util.logging.Logger;

public class Multithread_sync 
{
public synchronized void wish(String name) throws InterruptedException
{
    for(int i=1;i<=10;i++)
    {
        System.out.println("child");
        Thread.sleep(1000);
        System.out.println(name);
    }
}}

class MyThread extends Thread
{
    Multithread_sync d;
    String name;
    MyThread(Multithread_sync d,String name)
    {
        this.d=d;
        this.name=name;
    }
    public void run()
    {
        try 
        {
            d.wish(name);
        }
        catch (InterruptedException ex) 
        {
            Logger.getLogger(MyThread.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }}
class Demo4
{
    public static void main(String[] args) 
    {
        Multithread_sync d=new Multithread_sync();
        MyThread t1=new MyThread(d,"abc");
        MyThread t2=new MyThread(d,"xyz");
        t1.start();
        t2.start();
    }
}