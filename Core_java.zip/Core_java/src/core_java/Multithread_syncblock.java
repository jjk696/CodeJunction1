/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core_java;

import java.util.logging.Level;
import java.util.logging.Logger;

public class Multithread_syncblock
{
public synchronized void wish(String name) throws InterruptedException
{   
    synchronized(this)
   {
    for(int i=1;i<=10;i++)
    {
        System.out.println("child");
        Thread.sleep(1000);
        System.out.println(name);
    }
   } 
}
}
class MyThread1 extends Thread
{
    Multithread_syncblock d;
    String name;
    MyThread1(Multithread_syncblock d,String name)
    {
        this.d=d;
        this.name=name;
    }
    public void run()
    {
        try 
        {
            d.wish(name);
        } 
        catch (InterruptedException ex) {
            Logger.getLogger(MyThread.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
}
class Demo5
{
    public static void main(String[] args) 
    {
        Multithread_syncblock d=new Multithread_syncblock();
        MyThread1 t1=new MyThread1(d,"abc");
        MyThread1 t2=new MyThread1(d,"xyz");
        t1.start();
        t2.start();
    }
}
