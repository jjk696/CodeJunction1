/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core_java;

public class Pattern2 
{
    public static void main(String[] args) {
        int m=3,n=1;
        for(int i=1;i<=4;i++)
        {
            for(int j=1;j<=4;j++)
            {
                if(i%2==1)
                {
                    if(j%2==1||m>=j)
                    {
                        System.out.print(" ");
                    }
                    else
                    {
                        if(j>m)
                        {
                            System.out.print(n);
                            n=n+1;
                        }
                    }
                }
                if(i%2==0 || m>=j)
                {
                    if(j%2==0)
                    {
                        System.out.print(" ");
                    }
                    else
                    {
                       if(j>m)
                       {
                           System.out.print(n);
                           n=n+1;
                       }
                    }
                }
            }
            n=1;
            m=m-1;
            System.out.println(" ");
        }
    }
}
