/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core_java;
public class Pattern_1 
{
    public static void main(String[] args) 
    {
     int m=3,n=2;
     for(int i=1;i<=5;i++)
     {
         if(i<=3)
         {
             for(int j=1;j<=3;j++)
             {
                 if(j<=i)
                 {
                     System.out.print(m);
                     m=m-1;
                 }
                 else
                 {
                     System.out.print(" ");
                 }
             }
             m=3;
             System.out.println(" ");
         }
         else
         {
             for(int j=1;j<=3;j++)
             {
                 if(j<=i-n)
                 {
                     System.out.print(m);
                     m=m-1;
                 }
                 else
                 {
                     System.out.print(" ");
                 }
             }
             n=n+2;
             m=3;
             System.out.println(" ");
         }
     }
    }
}
