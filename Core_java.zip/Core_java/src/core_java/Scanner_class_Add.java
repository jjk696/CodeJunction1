/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core_java;
import java.util.Scanner;
public class Scanner_class_Add 
{
    public static void main(String[] args) 
    {
        Scanner obj=new Scanner(System.in);
        int a,b,c;
        a=obj.nextInt();
        b=obj.nextInt();
        c=a+b;
        System.out.println(c);  
    }
}
