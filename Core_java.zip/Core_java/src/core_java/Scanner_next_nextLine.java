/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core_java;
import java.util.Scanner;
public class Scanner_next_nextLine 
{
    public static void main(String[] args)
    {
        Scanner obj1=new Scanner(System.in);
        String f;
        f=obj1.nextLine();
        System.out.println(f);
        f=obj1.next();
        System.out.println(f);     
    }
}