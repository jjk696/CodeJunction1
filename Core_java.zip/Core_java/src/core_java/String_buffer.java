/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core_java;

/**
 *
 * @author pRIyA sONi
 */
public class String_buffer 
{
    public static void main(String[] args)
    {
    StringBuffer sb=new StringBuffer("hello");
        System.out.println(sb.reverse());
        System.out.println(sb.reverse());
        System.out.println(sb.append("java"));
        System.out.println(sb.delete(0,3));    
        System.out.println(sb.insert(1,"welcome"));
        System.out.println(sb.replace(3,10,"python"));
    }
}
