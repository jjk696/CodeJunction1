/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core_java;
public class String_intseparate 
{
    public static void main(String[] args) 
    {
    int a=0;
    String S1="java 234 is 5 independent 456";
    for(int i=0;i<S1.length();i++)
    {
      if(S1.charAt(i)<=' ')
      {
          if(S1.charAt(i+1)<='9')
          {
              for(int j=i;j<=S1.length();j++)
              {
                System.out.print(S1.charAt(j));
                a=a+S1.charAt(i);
              }
              
      }  
    }
        System.out.println(a);
    }  
}