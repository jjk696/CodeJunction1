/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core_java;

/**
 *
 * @author pRIyA sONi
 */
public class String_try {
    public static void main(String[] args) 
    {
        String S1="hello";
        String S3="HELLO";
        String S4="java is independent language";
        String S5="  welcome  ";
        String S6="hello";
        System.out.println(S1.equals(S3));
        System.out.println(S1.equalsIgnoreCase(S3));
        System.out.println(S1.charAt(1));
        System.out.println(S1.length());
        System.out.println(S1.substring(1,3));
        System.out.println(S1.concat("java"));
        System.out.println(S1.indexOf('l'));
    }   
}
