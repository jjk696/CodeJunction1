package core_java;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author pRIyA sONi
 */
public class String_vowels_spaces 
{
    public static void main(String[] args) 
    {
      String S1="Java is independent language";
      int m=0,n=0;
      for(int p=0;p<S1.length();p++)
      {
       if(S1.charAt(p)=='a'||S1.charAt(p)=='e'||S1.charAt(p)=='i'||S1.charAt(p)=='o'||S1.charAt(p)=='u')
       {
           m=m+1;
       }
      }
        System.out.println("Number of vowels are "+m);
      for(int p=0;p<S1.length();p++)
      {
       if(S1.charAt(p)==' ')
       {
           n=n+1;
       }
      }
        System.out.println("Number of spaces are "+n);
   }
}