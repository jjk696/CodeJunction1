/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core_java;

/**
 *
 * @author pRIyA sONi
 */
public class String_welcome
{
    public static void main(String[] args) 
    {
        String S1="welcome";
        for(int i=0;i<S1.length();i++)
        {
            for(int j=0;j<=6;j++)
            {
                if(i==j)
                {
                    System.out.print(S1.charAt(i));
                }
                else
                {
                    System.out.print(" ");
                }
            }
            System.out.println(" ");
        }   
    }
   
}
