/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core_java;

public class Thread_currentthread extends Thread
{
    public static void main(String[] args) 
    {
        System.out.println(Thread.currentThread().getPriority());    
    }    
}
