/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core_java;

public class  Thread_demo extends Thread
{
   public void run()
   {
       for(int i=0;i<=9;i++)
       {
           System.out.println("child");
       }
   }
}
class Demo1
{
    public static void main(String[] args) 
    {
    Thread_demo t1=new Thread_demo();
    t1.start();
    for(int j=0;j<=9;j++)
    {
        System.out.println("main");
    }    
    }
}
