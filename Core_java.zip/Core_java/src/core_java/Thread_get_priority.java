/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core_java;

public class Thread_get_priority extends Thread
{    
}

class A
{
    public static void main(String[] args) {
        Thread_get_priority t1=new Thread_get_priority();
        System.out.println(t1.getPriority());
    }
}