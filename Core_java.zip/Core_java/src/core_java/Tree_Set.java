/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core_java;
import java.util.TreeSet;
public class Tree_Set {
    public static void main(String[] args) {
        TreeSet ts=new TreeSet();
        ts.add("abc");
        ts.add("xyz");
        ts.add("lmn");
        ts.add("james");
        ts.add("abc");
        System.out.println(ts);
    }
    
}
