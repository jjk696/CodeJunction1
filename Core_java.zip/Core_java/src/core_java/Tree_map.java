/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core_java;
import java.util.TreeMap;
public class Tree_map {
    public static void main(String[] args) {
    TreeMap tm=new TreeMap();
    tm.put(1,"xyz");
    try
    {
    tm.put(null,"xy");
    }
    catch(Exception e)
    {
    System.out.println(e);
    }
    tm.put(2,"null");
    tm.put(1,"abc");
    tm.put(3,"efg");
    System.out.println(tm);
    }
}
