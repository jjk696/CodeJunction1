/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core_java;
import java.util.TreeMap;
public class Tree_map_methods {
    public static void main(String[] args) {
    TreeMap tm=new TreeMap();
    try
    {
    tm.put(null,"xy");
    }
    catch(Exception e)
    {
    System.out.println(e);
    }
    tm.put(2,"null");
    tm.put(1,"lmn");
    tm.put(3,"efg");
    tm.put(1,"abc");
    System.out.println(tm); 
    
        int a=tm.size();
        System.out.println(a);
        boolean b=tm.containsKey(4);
        System.out.println(b);
        boolean c=tm.containsValue("lmn");
        System.out.println(c);
        Object d=tm.get(4);
        System.out.println(d);
        Object e=tm.firstKey();
        System.out.println(e);
        Object f=tm.lastKey();
        System.out.println(f);
        Object g=tm.put(4,"abc");
        System.out.println(tm);
        Object h=tm.remove(4);
        System.out.println(h);
        Object i=tm.lowerKey(2);
        System.out.println(i);
        Object j=tm.floorKey(2);
        System.out.println(j);
        Object k=tm.ceilingKey(2);
        System.out.println(k);
        Object l=tm.higherKey(2);
        System.out.println(l);
    }
}
