/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core_java;

/**
 *
 * @author pRIyA sONi
 */
public class Wrapper_class 
{
    public static void main(String[] args) {
        String s[]={"10","20"};
        System.out.println("sum is "+s[0]+s[1]);
        int x=Integer.parseInt(s[0]);
        int y=Integer.parseInt(s[1]);
        int z=x+y;
        System.out.println("sum is "+z);
    }
    
}
