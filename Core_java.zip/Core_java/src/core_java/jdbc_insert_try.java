/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core_java;
import java.sql.*;
public class jdbc_insert_try {
public static void main(String[] args) {
    try
    {
      Class.forName("com.mysql.jdbc.Driver");
      Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/demo","root","123");
      PreparedStatement ps=con.prepareStatement("insert into user_info values(?,?,?,?,?,?)");
      

      ps.setString(1,"abc");
      ps.setString(2, "123");
      ps.setString(3,"123");
      ps.setString(4,"h no 69, phase7");
      ps.setString(5,"abc@gmail.com");
      ps.setString(6,"123456");
      int rs=ps.executeUpdate();
   }
    catch(Exception e)
        {
            System.out.println(e); 
        }
}
}    
