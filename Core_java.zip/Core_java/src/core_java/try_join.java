/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core_java;

import java.util.logging.Level;
import java.util.logging.Logger;

public class try_join extends Thread
{
  public void run()
  {
      for(int i=1;i<=5;i++)
      {  
          System.out.println("a");
      }
  }
}

class Demo12
{
    public static void main(String[] args) {
       
            try_join t1=new try_join();
            t1.start();
            try {
          t1.join(1000);
      } catch (InterruptedException ex) {
          Logger.getLogger(try_join.class.getName()).log(Level.SEVERE, null, ex);
      }
        for(int i=1;i<=5;i++)
        {
            System.out.println("b");
        }
    }
}
