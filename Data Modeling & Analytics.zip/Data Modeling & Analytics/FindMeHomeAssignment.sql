-- Create ClientName Table
CREATE TABLE ClientName (
    ClientID NUMBER PRIMARY KEY,
    Name VARCHAR2(100 CHAR) NOT NULL,
    Address VARCHAR2(255 CHAR) NOT NULL,
    Phone VARCHAR2(20 CHAR),
    Email VARCHAR2(100 CHAR),
    DateOfBirth DATE NOT NULL
);

-- Create AgencyBranch Table
CREATE TABLE AgencyBranch (
    BranchID NUMBER PRIMARY KEY,
    Name VARCHAR2(100 CHAR) NOT NULL,
    Address VARCHAR2(255 CHAR) NOT NULL,
    ContactDetails VARCHAR2(100 CHAR)
);

-- Create RealEstateAgent Table
CREATE TABLE RealEstateAgent (
    AgentID NUMBER PRIMARY KEY,
    Name VARCHAR2(100 CHAR) NOT NULL,
    ContactDetails VARCHAR2(100 CHAR),
    BranchID NUMBER,
    FOREIGN KEY (BranchID) REFERENCES AgencyBranch (BranchID)
);



-- Create RealEstateProperty Table
CREATE TABLE RealEstateProperty (
    PropertyID NUMBER PRIMARY KEY,
    Address VARCHAR2(255 CHAR) NOT NULL,
    Location VARCHAR2(100 CHAR),
    Description VARCHAR(255 CHAR),
    AccommodationDetails VARCHAR(255),
    Price NUMBER(10,2) NOT NULL,
    Type VARCHAR2(50 CHAR) NOT NULL,
    NumberOfRooms NUMBER NOT NULL,
    BranchID NUMBER,
    FOREIGN KEY (BranchID) REFERENCES AgencyBranch (BranchID)
);



-- Create PropertyViewing Table
CREATE TABLE PropertyViewing (
    ViewingID NUMBER PRIMARY KEY,
    ClientID NUMBER,
    PropertyID NUMBER,
    DateTime TIMESTAMP NOT NULL,
    Comments VARCHAR2(255 CHAR),
    FOREIGN KEY (ClientID) REFERENCES ClientName(ClientID) ON DELETE CASCADE, -- Optional: handles deletion of clients
    FOREIGN KEY (PropertyID) REFERENCES RealEstateProperty(PropertyID) ON DELETE CASCADE -- Optional: handles deletion of properties
);
-- Create PropertySale Table
CREATE TABLE PropertySale (
    SaleID NUMBER PRIMARY KEY,
    PropertyID NUMBER,
    ClientID NUMBER,
    SellingPrice NUMBER(10,2) NOT NULL,
    SaleDate DATE NOT NULL,
    AgentID NUMBER,
    FOREIGN KEY (PropertyID) REFERENCES RealEstateProperty (PropertyID),
    FOREIGN KEY (ClientID) REFERENCES ClientName (ClientID),
    FOREIGN KEY (AgentID) REFERENCES RealEstateAgent (AgentID)
);

-- Create PropertyRental Table
CREATE TABLE PropertyRental (
    RentalID NUMBER PRIMARY KEY,
    PropertyID NUMBER,
    LandlordID NUMBER,
    TenantID NUMBER,
    RentPerMonth NUMBER(10,2) NOT NULL,
    Deposit NUMBER(10,2),
    StartDate DATE NOT NULL,
    EndDate DATE,
    ProtectionScheme VARCHAR2(100 CHAR),
    FOREIGN KEY (PropertyID) REFERENCES RealEstateProperty (PropertyID),
    FOREIGN KEY (LandlordID) REFERENCES ClientName (ClientID),
    FOREIGN KEY (TenantID) REFERENCES ClientName (ClientID)
);

-- Create Appointment Table
CREATE TABLE Appointment (
    AppointmentID NUMBER PRIMARY KEY,
    ClientID NUMBER,
    AgentID NUMBER,
    PropertyID NUMBER,
    AppointmentDate DATE NOT NULL,
    AppointmentTime TIMESTAMP NOT NULL,
    Status VARCHAR2(50 CHAR),
    FOREIGN KEY (ClientID) REFERENCES ClientName (ClientID),
    FOREIGN KEY (AgentID) REFERENCES RealEstateAgent (AgentID),
    FOREIGN KEY (PropertyID) REFERENCES RealEstateProperty (PropertyID)
);

-- Create TransactionHistory Table
CREATE TABLE TransactionHistory (
    TransactionID NUMBER PRIMARY KEY,
    ClientID NUMBER,
    PropertyID NUMBER,
    TransactionType VARCHAR2(50 CHAR),
    Amount NUMBER(10,2) NOT NULL,
    TransactionDate DATE NOT NULL,
    FOREIGN KEY (ClientID) REFERENCES ClientName (ClientID),
    FOREIGN KEY (PropertyID) REFERENCES RealEstateProperty (PropertyID)
);

-- Create RentalAgreement Table
CREATE TABLE RentalAgreement (
    AgreementID NUMBER PRIMARY KEY,
    RentalID NUMBER,
    LandlordID NUMBER,
    TenantID NUMBER,
    StartDate DATE NOT NULL,
    EndDate DATE NOT NULL,
    RentAmount NUMBER(10,2) NOT NULL,
    DepositAmount NUMBER(10,2),
    TermsConditions VARCHAR(255 CHAR),
    FOREIGN KEY (RentalID) REFERENCES PropertyRental (RentalID),
    FOREIGN KEY (LandlordID) REFERENCES ClientName(ClientID),
    FOREIGN KEY (TenantID) REFERENCES ClientName (ClientID)
);



Select * from ClientName;
Select * from RealEstateAgent;
Select * from AgencyBranch;
Select * from RealEstateProperty;
Select * from PropertyViewing;
Select * from PropertySale;
Select * from PropertyRental;
Select * from Appointment;
Select * from TransactionHistory;
Select * from RentalAgreement;

DROP TABLE ClientName;
DROP TABLE RealEstateAgent;
DROP TABLE AgencyBranch;
DROP TABLE RealEstateProperty;
DROP TABLE PropertyViewing;
DROP TABLE PropertySale;
DROP TABLE PropertyRental;
DROP TABLE Appointment;
DROP TABLE TransactionHistory;
DROP TABLE RentalAgreement;


INSERT INTO ClientName (ClientID, Name, Address, Phone, Email, DateOfBirth) VALUES
(1, 'John Doe', '123 Elm Street, Springfield', '555-1234', 'john.doe@example.com', TO_DATE('1985-03-25', 'YYYY-MM-DD'));

INSERT INTO ClientName (ClientID, Name, Address, Phone, Email, DateOfBirth) VALUES
(2, 'Jane Smith', '456 Oak Avenue, Springfield', '555-5678', 'jane.smith@example.com', TO_DATE('1990-07-15', 'YYYY-MM-DD'));

INSERT INTO ClientName (ClientID, Name, Address, Phone, Email, DateOfBirth) VALUES
(3, 'Alice Johnson', '789 Pine Road, Springfield', '555-8765', 'alice.johnson@example.com', TO_DATE('1982-11-30', 'YYYY-MM-DD'));

INSERT INTO ClientName (ClientID, Name, Address, Phone, Email, DateOfBirth) VALUES
(4, 'Bob Brown', '101 Maple Lane, Springfield', '555-4321', 'bob.brown@example.com', TO_DATE('1979-09-12', 'YYYY-MM-DD'));

INSERT INTO ClientName (ClientID, Name, Address, Phone, Email, DateOfBirth) VALUES
(5, 'Carol White', '202 Birch Street, Springfield', '555-6789', 'carol.white@example.com', TO_DATE('1993-02-18', 'YYYY-MM-DD'));

INSERT INTO ClientName (ClientID, Name, Address, Phone, Email, DateOfBirth) VALUES
(6, 'David Green', '303 Cedar Road, Springfield', '555-3456', 'david.green@example.com', TO_DATE('1988-12-07', 'YYYY-MM-DD'));

INSERT INTO ClientName (ClientID, Name, Address, Phone, Email, DateOfBirth) VALUES
(7, 'Emma Blue', '404 Walnut Drive, Springfield', '555-7890', 'emma.blue@example.com', TO_DATE('1986-05-20', 'YYYY-MM-DD'));

INSERT INTO ClientName (ClientID, Name, Address, Phone, Email, DateOfBirth) VALUES
(8, 'Robert Garcia', '505 Spruce Court, Springfield', '555-1357', 'robert.garcia@example.com', TO_DATE('1993-06-20', 'YYYY-MM-DD'));

INSERT INTO ClientName (ClientID, Name, Address, Phone, Email, DateOfBirth) VALUES
(9, 'Jennifer Martinez', '606 Pine Hill, Springfield', '555-9876', 'jennifer.martinez@example.com', TO_DATE('1991-08-09', 'YYYY-MM-DD'));

INSERT INTO ClientName (ClientID, Name, Address, Phone, Email, DateOfBirth) VALUES
(10, 'Charles Hernandez', '707 Oak Grove, Springfield', '555-6543', 'charles.hernandez@example.com', TO_DATE('1980-12-25', 'YYYY-MM-DD'));
INSERT INTO ClientName (ClientID, Name, Address, Phone, Email, DateOfBirth) VALUES
(11, 'William Lee', '808 Maple Lane, Springfield', '555-3210', 'william.lee@example.com', TO_DATE('1987-02-14', 'YYYY-MM-DD'));

INSERT INTO ClientName (ClientID, Name, Address, Phone, Email, DateOfBirth) VALUES
(12, 'Susan Taylor', '909 Oak Street, Springfield', '555-4567', 'susan.taylor@example.com', TO_DATE('1994-05-30', 'YYYY-MM-DD'));

INSERT INTO ClientName (ClientID, Name, Address, Phone, Email, DateOfBirth) VALUES
(13, 'David Thompson', '123 Birch Avenue, Springfield', '555-7890', 'david.thompson@example.com', TO_DATE('1981-11-11', 'YYYY-MM-DD'));

INSERT INTO ClientName (ClientID, Name, Address, Phone, Email, DateOfBirth) VALUES
(14, 'Jessica White', '234 Cedar Road, Springfield', '555-2345', 'jessica.white@example.com', TO_DATE('1992-03-07', 'YYYY-MM-DD'));

INSERT INTO ClientName (ClientID, Name, Address, Phone, Email, DateOfBirth) VALUES
(15, 'Daniel Harris', '345 Elm Street, Springfield', '555-6789', 'daniel.harris@example.com', TO_DATE('1984-08-19', 'YYYY-MM-DD'));

INSERT INTO ClientName (ClientID, Name, Address, Phone, Email, DateOfBirth) VALUES
(16, 'Sarah Clark', '456 Pine Court, Springfield', '555-1357', 'sarah.clark@example.com', TO_DATE('1990-09-22', 'YYYY-MM-DD'));

INSERT INTO ClientName (ClientID, Name, Address, Phone, Email, DateOfBirth) VALUES
(17, 'Christopher Rodriguez', '567 Maple Avenue, Springfield', '555-2468', 'christopher.rodriguez@example.com', TO_DATE('1989-06-30', 'YYYY-MM-DD'));

INSERT INTO ClientName (ClientID, Name, Address, Phone, Email, DateOfBirth) VALUES
(18, 'Nancy Lewis', '678 Spruce Boulevard, Springfield', '555-3579', 'nancy.lewis@example.com', TO_DATE('1993-01-15', 'YYYY-MM-DD'));

INSERT INTO ClientName (ClientID, Name, Address, Phone, Email, DateOfBirth) VALUES
(19, 'George Walker', '789 Oak Drive, Springfield', '555-4680', 'george.walker@example.com', TO_DATE('1985-04-28', 'YYYY-MM-DD'));

INSERT INTO ClientName (ClientID, Name, Address, Phone, Email, DateOfBirth) VALUES
(20, 'Katherine Hall', '890 Pine Lane, Springfield', '555-5791', 'katherine.hall@example.com', TO_DATE('1995-12-01', 'YYYY-MM-DD'));



INSERT INTO AgencyBranch (BranchID, Name, Address, ContactDetails) VALUES 
(1, 'Springfield North', '1 North Ave, Springfield', '555-1001');

INSERT INTO AgencyBranch (BranchID, Name, Address, ContactDetails) VALUES 
(2, 'Springfield East', '2 East Ave, Springfield', '555-1002');

INSERT INTO AgencyBranch (BranchID, Name, Address, ContactDetails) VALUES 
(3, 'Springfield South', '3 South Ave, Springfield', '555-1003');

INSERT INTO AgencyBranch (BranchID, Name, Address, ContactDetails) VALUES 
(4, 'Springfield West', '4 West Ave, Springfield', '555-1004');

INSERT INTO AgencyBranch (BranchID, Name, Address, ContactDetails) VALUES 
(5, 'Springfield Central', '5 Central Ave, Springfield', '555-1005');

INSERT INTO AgencyBranch (BranchID, Name, Address, ContactDetails) VALUES 
(6, 'Springfield Suburbs', '6 Suburb St, Springfield', '555-1006');



INSERT INTO RealEstateAgent (AgentID, Name, ContactDetails, BranchID) VALUES 
(1, 'Michael Scott', '555-0011', 1);

INSERT INTO RealEstateAgent (AgentID, Name, ContactDetails, BranchID) VALUES 
(2, 'Dwight Schrute', '555-0022', 1);

INSERT INTO RealEstateAgent (AgentID, Name, ContactDetails, BranchID) VALUES 
(3, 'Jim Halpert', '555-0033', 2);

INSERT INTO RealEstateAgent (AgentID, Name, ContactDetails, BranchID) VALUES 
(4, 'Pam Beesly', '555-0044', 2);

INSERT INTO RealEstateAgent (AgentID, Name, ContactDetails, BranchID) VALUES 
(5, 'Ryan Howard', '555-0055', 3);

INSERT INTO RealEstateAgent (AgentID, Name, ContactDetails, BranchID) VALUES 
(6, 'Angela Martin', '555-0066', 3);

INSERT INTO RealEstateAgent (AgentID, Name, ContactDetails, BranchID) VALUES 
(7, 'Oscar Martinez', '555-0077', 4);



-- Insert Property Data
INSERT INTO RealEstateProperty (PropertyID, Address, Location, Description, AccommodationDetails, Price, Type, NumberOfRooms, BranchID) VALUES 
(1, '123 Elm Street', 'North Springfield', 'Cozy 2-bedroom house.', '2 bedrooms, 1 bathroom', 250000, 'House', 2, 1);

INSERT INTO RealEstateProperty (PropertyID, Address, Location, Description, AccommodationDetails, Price, Type, NumberOfRooms, BranchID) VALUES 
(2, '456 Oak Avenue', 'East Springfield', 'Spacious 3-bedroom apartment.', '3 bedrooms, 2 bathrooms', 350000, 'Apartment', 3, 2);

INSERT INTO RealEstateProperty (PropertyID, Address, Location, Description, AccommodationDetails, Price, Type, NumberOfRooms, BranchID) VALUES 
(3, '789 Pine Road', 'South Springfield', 'Modern 4-bedroom villa.', '4 bedrooms, 3 bathrooms', 500000, 'Villa', 3, 3);

INSERT INTO RealEstateProperty (PropertyID, Address, Location, Description, AccommodationDetails, Price, Type, NumberOfRooms, BranchID) VALUES 
(4, '101 Maple Lane', 'West Springfield', 'Charming 3-bedroom house.', '3 bedrooms, 2 bathrooms', 300000, 'House', 3, 4);

INSERT INTO RealEstateProperty (PropertyID, Address, Location, Description, AccommodationDetails, Price, Type, NumberOfRooms, BranchID) VALUES 
(5, '202 Birch Street', 'Central Springfield', 'Luxury 5-bedroom mansion.', '5 bedrooms, 4 bathrooms', 750000, 'Mansion', 5, 5);

INSERT INTO RealEstateProperty (PropertyID, Address, Location, Description, AccommodationDetails, Price, Type, NumberOfRooms, BranchID) VALUES 
(6, '303 Cedar Road', 'Suburban Springfield', 'Comfortable 2-bedroom condo.', '2 bedrooms, 1 bathroom', 200000, 'Condo', 2, 6);

-- Insert additional Property Data
INSERT INTO RealEstateProperty (PropertyID, Address, Location, Description, AccommodationDetails, Price, Type, NumberOfRooms, BranchID) VALUES 
(7, '404 Willow Street', 'Old Town Springfield', 'Historic 4-bedroom house.', '4 bedrooms, 3 bathrooms', 450000, 'House', 4, 1);

INSERT INTO RealEstateProperty (PropertyID, Address, Location, Description, AccommodationDetails, Price, Type, NumberOfRooms, BranchID) VALUES 
(8, '505 Pine Avenue', 'New Springfield', 'Modern 2-bedroom apartment.', '2 bedrooms, 2 bathrooms', 300000, 'Apartment', 2, 2);

INSERT INTO RealEstateProperty (PropertyID, Address, Location, Description, AccommodationDetails, Price, Type, NumberOfRooms, BranchID) VALUES 
(9, '606 Maple Drive', 'Downtown Springfield', 'Luxurious 3-bedroom penthouse.', '3 bedrooms, 3 bathrooms', 900000, 'Penthouse', 3, 3);

INSERT INTO RealEstateProperty (PropertyID, Address, Location, Description, AccommodationDetails, Price, Type, NumberOfRooms, BranchID) VALUES 
(10, '707 Oak Boulevard', 'South Springfield', 'Spacious 5-bedroom house.', '5 bedrooms, 4 bathrooms', 600000, 'House', 5, 4);

INSERT INTO RealEstateProperty (PropertyID, Address, Location, Description, AccommodationDetails, Price, Type, NumberOfRooms, BranchID) VALUES 
(11, '808 Cedar Lane', 'North Springfield', 'Cozy 3-bedroom cottage.', '3 bedrooms, 2 bathrooms', 320000, 'Cottage', 3, 5);

INSERT INTO RealEstateProperty (PropertyID, Address, Location, Description, AccommodationDetails, Price, Type, NumberOfRooms, BranchID) VALUES 
(14, '1111 Spruce Street', 'Central Springfield', 'Charming 2-bedroom flat.', '2 bedrooms, 1 bathroom', 220000, 'Flat', 2, 3);

INSERT INTO RealEstateProperty (PropertyID, Address, Location, Description, AccommodationDetails, Price, Type, NumberOfRooms, BranchID) VALUES 
(15, '1212 Pine Hill', 'Downtown Springfield', 'Luxurious 5-bedroom estate.', '5 bedrooms, 4 bathrooms', 1200000, 'Estate', 5, 5);

INSERT INTO RealEstateProperty (PropertyID, Address, Location, Description, AccommodationDetails, Price, Type, NumberOfRooms, BranchID) VALUES 
(16, '1313 Oak Ridge', 'Old Town Springfield', 'Modern 3-bedroom loft.', '3 bedrooms, 2 bathrooms', 410000, 'Loft', 3, 5);

INSERT INTO RealEstateProperty (PropertyID, Address, Location, Description, AccommodationDetails, Price, Type, NumberOfRooms, BranchID) VALUES 
(17, '1414 Maple Grove', 'Suburban Springfield', 'Cozy 2-bedroom apartment.', '2 bedrooms, 1 bathroom', 210000, 'Apartment', 2, 6);

INSERT INTO RealEstateProperty (PropertyID, Address, Location, Description, AccommodationDetails, Price, Type, NumberOfRooms, BranchID) VALUES 
(18, '1515 Willow Way', 'North Springfield', 'Elegant 4-bedroom home.', '4 bedrooms, 3 bathrooms', 550000, 'House', 4, 1);

INSERT INTO RealEstateProperty (PropertyID, Address, Location, Description, AccommodationDetails, Price, Type, NumberOfRooms, BranchID) VALUES 
(19, '1616 Cedar Court', 'East Springfield', 'Comfortable 3-bedroom bungalow.', '3 bedrooms, 2 bathrooms', 325000, 'Bungalow', 3, 2);

INSERT INTO RealEstateProperty (PropertyID, Address, Location, Description, AccommodationDetails, Price, Type, NumberOfRooms, BranchID) VALUES 
(20, '1717 Spruce Avenue', 'South Springfield', 'Luxury 6-bedroom villa.', '6 bedrooms, 5 bathrooms', 2000000, 'Villa', 6, 3);


INSERT INTO RealEstateProperty (PropertyID, Address, Location, Description, AccommodationDetails, Price, Type, NumberOfRooms, BranchID) VALUES 
(21, '808 Maple Street', 'South Springfield', 'Lovely 3-bedroom cottage.', '3 bedrooms, 2 bathrooms', 320000, 'Cottage', 3, 1);

INSERT INTO RealEstateProperty (PropertyID, Address, Location, Description, AccommodationDetails, Price, Type, NumberOfRooms, BranchID) VALUES 
(22, '909 Pine Avenue', 'North Springfield', 'Charming 2-bedroom flat.', '2 bedrooms, 1 bathroom', 280000, 'Flat', 2, 2);

INSERT INTO RealEstateProperty (PropertyID, Address, Location, Description, AccommodationDetails, Price, Type, NumberOfRooms, BranchID) VALUES 
(23, '1000 Oak Street', 'East Springfield', 'Stylish 4-bedroom family home.', '4 bedrooms, 3 bathrooms', 450000, 'House', 4, 1);

INSERT INTO RealEstateProperty (PropertyID, Address, Location, Description, AccommodationDetails, Price, Type, NumberOfRooms, BranchID) VALUES 
(24, '1100 Maple Avenue', 'West Springfield', 'Cozy 3-bedroom bungalow.', '3 bedrooms, 2 bathrooms', 300000, 'Bungalow', 3, 2);

INSERT INTO RealEstateProperty (PropertyID, Address, Location, Description, AccommodationDetails, Price, Type, NumberOfRooms, BranchID) VALUES 
(25, '1200 Cedar Lane', 'North Springfield', 'Modern 5-bedroom villa.', '5 bedrooms, 4 bathrooms', 600000, 'Villa', 5, 3);

INSERT INTO RealEstateProperty (PropertyID, Address, Location, Description, AccommodationDetails, Price, Type, NumberOfRooms, BranchID) VALUES 
(26, '1300 Birch Street', 'Central Springfield', 'Elegant 2-bedroom apartment.', '2 bedrooms, 1 bathroom', 220000, 'Apartment', 2, 4);

INSERT INTO RealEstateProperty (PropertyID, Address, Location, Description, AccommodationDetails, Price, Type, NumberOfRooms, BranchID) VALUES 
(28, '1500 Willow Way', 'Downtown Springfield', 'Charming 3-bedroom townhouse.', '3 bedrooms, 2 bathrooms', 380000, 'Townhouse', 3, 6);

INSERT INTO RealEstateProperty (PropertyID, Address, Location, Description, AccommodationDetails, Price, Type, NumberOfRooms, BranchID) VALUES 
(29, '1600 Elm Avenue', 'Old Town Springfield', 'Spacious 5-bedroom mansion.', '5 bedrooms, 4 bathrooms', 900000, 'Mansion', 5, 1);

INSERT INTO RealEstateProperty (PropertyID, Address, Location, Description, AccommodationDetails, Price, Type, NumberOfRooms, BranchID) VALUES 
(30, '1700 Oak Boulevard', 'East Springfield', 'Comfortable 3-bedroom condo.', '3 bedrooms, 2 bathrooms', 250000, 'Condo', 3, 2);



-- Sample viewings for PropertyID 1
INSERT INTO PropertyViewing (ViewingID, ClientID, PropertyID, DateTime, Comments) VALUES
(1, 1, 1, SYSTIMESTAMP - INTERVAL '1' DAY, 'Liked the location.');
INSERT INTO PropertyViewing (ViewingID, ClientID, PropertyID, DateTime, Comments) VALUES
(2, 2, 1, SYSTIMESTAMP - INTERVAL '2' DAY, 'Considering an offer.');
INSERT INTO PropertyViewing (ViewingID, ClientID, PropertyID, DateTime, Comments) VALUES
(3, 3, 1, SYSTIMESTAMP - INTERVAL '3' DAY, 'Perfect for families.');
INSERT INTO PropertyViewing (ViewingID, ClientID, PropertyID, DateTime, Comments) VALUES
(4, 4, 1, SYSTIMESTAMP - INTERVAL '4' DAY, 'Very spacious.');
INSERT INTO PropertyViewing (ViewingID, ClientID, PropertyID, DateTime, Comments) VALUES
(5, 5, 1, SYSTIMESTAMP - INTERVAL '5' DAY, 'Great amenities.');
INSERT INTO PropertyViewing (ViewingID, ClientID, PropertyID, DateTime, Comments) VALUES
(6, 6, 1, SYSTIMESTAMP - INTERVAL '6' DAY, 'Would recommend.');
INSERT INTO PropertyViewing (ViewingID, ClientID, PropertyID, DateTime, Comments) VALUES
(7, 7, 1, SYSTIMESTAMP - INTERVAL '7' DAY, 'Nice layout.');
INSERT INTO PropertyViewing (ViewingID, ClientID, PropertyID, DateTime, Comments) VALUES
(8, 8, 1, SYSTIMESTAMP - INTERVAL '8' DAY, 'Good location.');
INSERT INTO PropertyViewing (ViewingID, ClientID, PropertyID, DateTime, Comments) VALUES
(9, 9, 1, SYSTIMESTAMP - INTERVAL '9' DAY, 'Affordable price.');
INSERT INTO PropertyViewing (ViewingID, ClientID, PropertyID, DateTime, Comments) VALUES
(10, 10, 1, SYSTIMESTAMP - INTERVAL '10' DAY, 'Too expensive.');
INSERT INTO PropertyViewing (ViewingID, ClientID, PropertyID, DateTime, Comments) VALUES
(11, 11, 1, SYSTIMESTAMP - INTERVAL '11' DAY, 'Loved the balcony.');
INSERT INTO PropertyViewing (ViewingID, ClientID, PropertyID, DateTime, Comments) VALUES
(12, 12, 1, SYSTIMESTAMP - INTERVAL '12' DAY, 'Ideal for couples.');
INSERT INTO PropertyViewing (ViewingID, ClientID, PropertyID, DateTime, Comments) VALUES
(13, 13, 1, SYSTIMESTAMP - INTERVAL '13' DAY, 'Great for families.');
INSERT INTO PropertyViewing (ViewingID, ClientID, PropertyID, DateTime, Comments) VALUES
(14, 14, 1, SYSTIMESTAMP - INTERVAL '14' DAY, 'Nice neighborhood.');

-- Sample viewings for PropertyID 2
INSERT INTO PropertyViewing (ViewingID, ClientID, PropertyID, DateTime, Comments) VALUES
(15, 1, 2, SYSTIMESTAMP - INTERVAL '1' DAY, 'Excellent amenities.');
INSERT INTO PropertyViewing (ViewingID, ClientID, PropertyID, DateTime, Comments) VALUES
(16, 2, 2, SYSTIMESTAMP - INTERVAL '2' DAY, 'Perfect for professionals.');
INSERT INTO PropertyViewing (ViewingID, ClientID, PropertyID, DateTime, Comments) VALUES
(17, 3, 2, SYSTIMESTAMP - INTERVAL '3' DAY, 'Spacious and bright.');
INSERT INTO PropertyViewing (ViewingID, ClientID, PropertyID, DateTime, Comments) VALUES
(18, 4, 2, SYSTIMESTAMP - INTERVAL '4' DAY, 'Great value.');



INSERT INTO PropertySale (SaleID, PropertyID, ClientID, SellingPrice, SaleDate, AgentID) VALUES 
(1, 1, 1, 240000, TO_DATE('2024-08-10', 'YYYY-MM-DD'), 1);

INSERT INTO PropertySale (SaleID, PropertyID, ClientID, SellingPrice, SaleDate, AgentID) VALUES 
(2, 2, 2, 340000, TO_DATE('2024-08-11', 'YYYY-MM-DD'), 2);

INSERT INTO PropertySale (SaleID, PropertyID, ClientID, SellingPrice, SaleDate, AgentID) VALUES 
(3, 3, 3, 480000, TO_DATE('2024-08-12', 'YYYY-MM-DD'), 3);

INSERT INTO PropertySale (SaleID, PropertyID, ClientID, SellingPrice, SaleDate, AgentID) VALUES 
(4, 4, 4, 290000, TO_DATE('2024-08-13', 'YYYY-MM-DD'), 4);

INSERT INTO PropertySale (SaleID, PropertyID, ClientID, SellingPrice, SaleDate, AgentID) VALUES 
(5, 5, 5, 720000, TO_DATE('2024-08-14', 'YYYY-MM-DD'), 5);

INSERT INTO PropertySale (SaleID, PropertyID, ClientID, SellingPrice, SaleDate, AgentID) VALUES 
(6, 6, 6, 190000, TO_DATE('2024-08-15', 'YYYY-MM-DD'), 6);


INSERT INTO PropertySale (SaleID, PropertyID, ClientID, SellingPrice, SaleDate, AgentID) VALUES 
(1, 1, 1, 240000.00, TO_DATE('2024-08-10', 'YYYY-MM-DD'), 1);

INSERT INTO PropertySale (SaleID, PropertyID, ClientID, SellingPrice, SaleDate, AgentID) VALUES 
(2, 2, 2, 340000.00, TO_DATE('2024-08-11', 'YYYY-MM-DD'), 2);

INSERT INTO PropertySale (SaleID, PropertyID, ClientID, SellingPrice, SaleDate, AgentID) VALUES 
(3, 3, 3, 480000.00, TO_DATE('2024-08-12', 'YYYY-MM-DD'), 3);

INSERT INTO PropertySale (SaleID, PropertyID, ClientID, SellingPrice, SaleDate, AgentID) VALUES 
(4, 4, 4, 290000.00, TO_DATE('2024-08-13', 'YYYY-MM-DD'), 4);

INSERT INTO PropertySale (SaleID, PropertyID, ClientID, SellingPrice, SaleDate, AgentID) VALUES 
(5, 5, 5, 720000.00, TO_DATE('2024-08-14', 'YYYY-MM-DD'), 5);

INSERT INTO PropertySale (SaleID, PropertyID, ClientID, SellingPrice, SaleDate, AgentID) VALUES 
(6, 6, 6, 190000.00, TO_DATE('2024-08-15', 'YYYY-MM-DD'), 6);

INSERT INTO PropertySale (SaleID, PropertyID, ClientID, SellingPrice, SaleDate, AgentID) VALUES 
(7, 7, 7, 250000.00, TO_DATE('2024-03-01', 'YYYY-MM-DD'), 1);

INSERT INTO PropertySale (SaleID, PropertyID, ClientID, SellingPrice, SaleDate, AgentID) VALUES 
(8, 8, 8, 350000.00, TO_DATE('2024-03-05', 'YYYY-MM-DD'), 2);

INSERT INTO PropertySale (SaleID, PropertyID, ClientID, SellingPrice, SaleDate, AgentID) VALUES 
(9, 9, 9, 450000.00, TO_DATE('2024-03-10', 'YYYY-MM-DD'), 3);

INSERT INTO PropertySale (SaleID, PropertyID, ClientID, SellingPrice, SaleDate, AgentID) VALUES 
(10, 10, 10, 300000.00, TO_DATE('2024-03-15', 'YYYY-MM-DD'), 4);

INSERT INTO PropertySale (SaleID, PropertyID, ClientID, SellingPrice, SaleDate, AgentID) VALUES 
(11, 11, 11, 700000.00, TO_DATE('2024-03-20', 'YYYY-MM-DD'), 5);

-- Insert into PropertyRental
INSERT INTO PropertyRental (RentalID, PropertyID, LandlordID, TenantID, RentPerMonth, Deposit, StartDate, EndDate, ProtectionScheme) VALUES
(1, 1, 1, 2, 1200, 2400, TO_DATE('2024-08-01', 'YYYY-MM-DD'), TO_DATE('2025-08-01', 'YYYY-MM-DD'), 'Deposit Protection Scheme A');

INSERT INTO PropertyRental (RentalID, PropertyID, LandlordID, TenantID, RentPerMonth, Deposit, StartDate, EndDate, ProtectionScheme) VALUES
(2, 2, 3, 4, 1500, 3000, TO_DATE('2024-09-01', 'YYYY-MM-DD'), TO_DATE('2025-09-01', 'YYYY-MM-DD'), 'Deposit Protection Scheme B');

INSERT INTO PropertyRental (RentalID, PropertyID, LandlordID, TenantID, RentPerMonth, Deposit, StartDate, EndDate, ProtectionScheme) VALUES
(3, 3, 5, 6, 1800, 3600, TO_DATE('2024-10-01', 'YYYY-MM-DD'), TO_DATE('2025-10-01', 'YYYY-MM-DD'), 'Deposit Protection Scheme C');

INSERT INTO PropertyRental (RentalID, PropertyID, LandlordID, TenantID, RentPerMonth, Deposit, StartDate, EndDate, ProtectionScheme) VALUES
(4, 4, 2, 3, 1000, 2000, TO_DATE('2024-11-01', 'YYYY-MM-DD'), TO_DATE('2025-11-01', 'YYYY-MM-DD'), 'Deposit Protection Scheme D');

INSERT INTO PropertyRental (RentalID, PropertyID, LandlordID, TenantID, RentPerMonth, Deposit, StartDate, EndDate, ProtectionScheme) VALUES
(5, 5, 4, 5, 2500, 5000, TO_DATE('2024-12-01', 'YYYY-MM-DD'), TO_DATE('2025-12-01', 'YYYY-MM-DD'), 'Deposit Protection Scheme E');

INSERT INTO PropertyRental (RentalID, PropertyID, LandlordID, TenantID, RentPerMonth, Deposit, StartDate, EndDate, ProtectionScheme) VALUES
(6, 6, 6, 1, 800, 1600, TO_DATE('2024-07-01', 'YYYY-MM-DD'), TO_DATE('2025-07-01', 'YYYY-MM-DD'), 'Deposit Protection Scheme F');

INSERT INTO PropertyRental (RentalID, PropertyID, LandlordID, TenantID, RentPerMonth, Deposit, StartDate, EndDate, ProtectionScheme) VALUES
(7, 7, 1, 3, 1800, 3600, TO_DATE('2024-09-01', 'YYYY-MM-DD'), TO_DATE('2025-09-01', 'YYYY-MM-DD'), 'Deposit Protection Scheme A');

INSERT INTO PropertyRental (RentalID, PropertyID, LandlordID, TenantID, RentPerMonth, Deposit, StartDate, EndDate, ProtectionScheme) VALUES
(8, 8, 2, 4, 2200, 4400, TO_DATE('2024-09-10', 'YYYY-MM-DD'), TO_DATE('2025-09-10', 'YYYY-MM-DD'), 'Deposit Protection Scheme B');

INSERT INTO PropertyRental (RentalID, PropertyID, LandlordID, TenantID, RentPerMonth, Deposit, StartDate, EndDate, ProtectionScheme) VALUES
(9, 9, 3, 5, 2500, 5000, TO_DATE('2024-09-15', 'YYYY-MM-DD'), TO_DATE('2025-09-15', 'YYYY-MM-DD'), 'Deposit Protection Scheme C');

INSERT INTO PropertyRental (RentalID, PropertyID, LandlordID, TenantID, RentPerMonth, Deposit, StartDate, EndDate, ProtectionScheme) VALUES
(10, 10, 4, 6, 2000, 4000, TO_DATE('2024-09-20', 'YYYY-MM-DD'), TO_DATE('2025-09-20', 'YYYY-MM-DD'), 'Deposit Protection Scheme D');

INSERT INTO PropertyRental (RentalID, PropertyID, LandlordID, TenantID, RentPerMonth, Deposit, StartDate, EndDate, ProtectionScheme) VALUES
(11, 11, 5, 1, 2300, 4600, TO_DATE('2024-10-01', 'YYYY-MM-DD'), TO_DATE('2025-10-01', 'YYYY-MM-DD'), 'Deposit Protection Scheme E');



INSERT INTO Appointment (AppointmentID, ClientID, AgentID, PropertyID, AppointmentDate, AppointmentTime, Status) VALUES 
(1, 1, 1, 1, TO_DATE('2024-08-20', 'YYYY-MM-DD'), TO_TIMESTAMP('2024-08-20 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), 'Scheduled');

INSERT INTO Appointment (AppointmentID, ClientID, AgentID, PropertyID, AppointmentDate, AppointmentTime, Status) VALUES 
(2, 2, 2, 2, TO_DATE('2024-08-21', 'YYYY-MM-DD'), TO_TIMESTAMP('2024-08-21 14:00:00', 'YYYY-MM-DD HH24:MI:SS'), 'Scheduled');

INSERT INTO Appointment (AppointmentID, ClientID, AgentID, PropertyID, AppointmentDate, AppointmentTime, Status) VALUES 
(3, 3, 3, 3, TO_DATE('2024-08-22', 'YYYY-MM-DD'), TO_TIMESTAMP('2024-08-22 16:00:00', 'YYYY-MM-DD HH24:MI:SS'), 'Rescheduled');

INSERT INTO Appointment (AppointmentID, ClientID, AgentID, PropertyID, AppointmentDate, AppointmentTime, Status) VALUES 
(4, 4, 4, 4, TO_DATE('2024-08-23', 'YYYY-MM-DD'), TO_TIMESTAMP('2024-08-23 11:00:00', 'YYYY-MM-DD HH24:MI:SS'), 'Completed');

INSERT INTO Appointment (AppointmentID, ClientID, AgentID, PropertyID, AppointmentDate, AppointmentTime, Status) VALUES 
(5, 5, 5, 5, TO_DATE('2024-08-24', 'YYYY-MM-DD'), TO_TIMESTAMP('2024-08-24 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), 'Cancelled');

INSERT INTO Appointment (AppointmentID, ClientID, AgentID, PropertyID, AppointmentDate, AppointmentTime, Status) VALUES 
(6, 6, 6, 6, TO_DATE('2024-08-25', 'YYYY-MM-DD'), TO_TIMESTAMP('2024-08-25 15:00:00', 'YYYY-MM-DD HH24:MI:SS'), 'Scheduled');



INSERT INTO TransactionHistory (TransactionID, ClientID, PropertyID, TransactionType, Amount, TransactionDate) VALUES 
(1, 1, 1, 'Purchase', 240000, TO_DATE('2024-08-10', 'YYYY-MM-DD'));

INSERT INTO TransactionHistory (TransactionID, ClientID, PropertyID, TransactionType, Amount, TransactionDate) VALUES 
(2, 2, 2, 'Purchase', 340000, TO_DATE('2024-08-11', 'YYYY-MM-DD'));

INSERT INTO TransactionHistory (TransactionID, ClientID, PropertyID, TransactionType, Amount, TransactionDate) VALUES 
(3, 3, 3, 'Purchase', 480000, TO_DATE('2024-08-12', 'YYYY-MM-DD'));

INSERT INTO TransactionHistory (TransactionID, ClientID, PropertyID, TransactionType, Amount, TransactionDate) VALUES 
(4, 4, 4, 'Purchase', 290000, TO_DATE('2024-08-13', 'YYYY-MM-DD'));

INSERT INTO TransactionHistory (TransactionID, ClientID, PropertyID, TransactionType, Amount, TransactionDate) VALUES 
(5, 5, 5, 'Purchase', 720000, TO_DATE('2024-08-14', 'YYYY-MM-DD'));

INSERT INTO TransactionHistory (TransactionID, ClientID, PropertyID, TransactionType, Amount, TransactionDate) VALUES 
(6, 6, 6, 'Purchase', 190000, TO_DATE('2024-08-15', 'YYYY-MM-DD'));



INSERT INTO RentalAgreement (AgreementID, RentalID, LandlordID, TenantID, StartDate, EndDate, RentAmount, DepositAmount, TermsConditions) VALUES 
(1, 1, 1, 2, TO_DATE('2024-08-01', 'YYYY-MM-DD'), TO_DATE('2025-08-01', 'YYYY-MM-DD'), 1200, 2400, 'Standard terms and conditions.');

INSERT INTO RentalAgreement (AgreementID, RentalID, LandlordID, TenantID, StartDate, EndDate, RentAmount, DepositAmount, TermsConditions) VALUES 
(2, 2, 3, 4, TO_DATE('2024-09-01', 'YYYY-MM-DD'), TO_DATE('2025-09-01', 'YYYY-MM-DD'), 1500, 3000, 'Standard terms and conditions.');

INSERT INTO RentalAgreement (AgreementID, RentalID, LandlordID, TenantID, StartDate, EndDate, RentAmount, DepositAmount, TermsConditions) VALUES 
(3, 3, 5, 6, TO_DATE('2024-10-01', 'YYYY-MM-DD'), TO_DATE('2025-10-01', 'YYYY-MM-DD'), 1800, 3600, 'Standard terms and conditions.');

INSERT INTO RentalAgreement (AgreementID, RentalID, LandlordID, TenantID, StartDate, EndDate, RentAmount, DepositAmount, TermsConditions) VALUES 
(4, 4, 2, 3, TO_DATE('2024-11-01', 'YYYY-MM-DD'), TO_DATE('2025-11-01', 'YYYY-MM-DD'), 1000, 2000, 'Standard terms and conditions.');

INSERT INTO RentalAgreement (AgreementID, RentalID, LandlordID, TenantID, StartDate, EndDate, RentAmount, DepositAmount, TermsConditions) VALUES 
(5, 5, 4, 5, TO_DATE('2024-12-01', 'YYYY-MM-DD'), TO_DATE('2025-12-01', 'YYYY-MM-DD'), 2500, 5000, 'Standard terms and conditions.');

INSERT INTO RentalAgreement (AgreementID, RentalID, LandlordID, TenantID, StartDate, EndDate, RentAmount, DepositAmount, TermsConditions) VALUES 
(6, 6, 6, 1, TO_DATE('2024-07-01', 'YYYY-MM-DD'), TO_DATE('2025-07-01', 'YYYY-MM-DD'), 800, 1600, 'Standard terms and conditions.');



COMMIT; 


Select * from ClientName;

Select * from RealEstateAgent;

Select * from AgencyBranch;

Select * from RealEstateProperty;

Select * from PropertyViewing;

Select * from PropertySale;

Select * from PropertyRental;

Select * from Appointment;

Select * from TransactionHistory;

Select * from RentalAgreement;




--Q1) Display details of the properties for rent with more than 10 views in the last 14 days.
--Relational Algebra Expression:

    ? PropertyID, Address, Location, Description, AccommodationDetails, Price, Type, NumberOfRooms (
    ? DateTime >= CURRENT_DATE - INTERVAL '14' DAY (PropertyViewing) ? PropertyID = PropertyID (RealEstateProperty)
    ? PropertyID, COUNT(ViewingID) AS ViewCount (PropertyViewing)
    ? ViewCount > 10
)

SELECT * FROM PropertyViewing WHERE DateTime IS NOT NULL;

SELECT PropertyID FROM PropertyViewing GROUP BY PropertyID HAVING COUNT(ViewingID) > 0;


SELECT *
FROM PropertyViewing
WHERE DateTime < SYSDATE - INTERVAL '14' DAY;

SELECT *
FROM PropertyViewing
ORDER BY ViewingID;


SELECT 
    COUNT(*) AS TotalViewings 
FROM 
    PropertyViewing;


SELECT 
    ViewingID, 
    ClientID, 
    PropertyID, 
    DateTime, 
    Comments
FROM 
    PropertyViewing
WHERE 
    DateTime < SYSDATE - INTERVAL '14' DAY;
    
 SELECT 
    p.PropertyID,
    p.Address,
    p.Location,
    p.Description,
    p.AccommodationDetails,
    p.Price,
    p.Type,
    p.NumberOfRooms
FROM 
    RealEstateProperty p
JOIN 
    PropertyViewing v ON p.PropertyID = v.PropertyID
WHERE 
    v.DateTime >= SYSTIMESTAMP - INTERVAL '14' DAY
GROUP BY 
    p.PropertyID,
    p.Address,
    p.Location,
    p.Description,
    p.AccommodationDetails,
    p.Price,
    p.Type,
    p.NumberOfRooms
HAVING 
    COUNT(v.ViewingID) > 10;


 

--Q2) Display details of the agent with the most properties sold in the month of March 2024.
--Relational Algebra Expression:
? AgentID, COUNT(SaleID) AS PropertiesSold (
    ? EXTRACT(MONTH FROM SaleDate) = 3 AND EXTRACT(YEAR FROM SaleDate) = 2024 (PropertySale)
)
? AgentID, Name (
    ? COUNT(PropertiesSold) = MAX(COUNT(PropertiesSold)) (AgentSales)
)


SELECT a.AgentID, a.Name, COUNT(ps.SaleID) AS PropertiesSold
FROM RealEstateAgent a
JOIN PropertySale ps ON a.AgentID = ps.AgentID
WHERE EXTRACT(MONTH FROM ps.SaleDate) = 3 AND EXTRACT(YEAR FROM ps.SaleDate) = 2024
GROUP BY a.AgentID, a.Name
ORDER BY PropertiesSold DESC
FETCH FIRST 1 ROWS ONLY;





--Object-Relational Design
--object-relational approach with two related entities from the schema: ClientName and RealEstateProperty. 
--use object types and object tables to model these entities and their relationships.

CREATE OR REPLACE TYPE ClientType1 AS OBJECT (
    ClientID NUMBER,
    Name VARCHAR2(100),
    Address VARCHAR2(255),
    Phone VARCHAR2(20),
    Email VARCHAR2(100),
    DateOfBirth DATE
);

CREATE OR REPLACE TYPE  RentalPropertyType1 AS OBJECT (
    PropertyID NUMBER,
    Address VARCHAR2(255),
    Location VARCHAR2(100),
    Description VARCHAR(200),
    AccommodationDetails VARCHAR(255),
    Price NUMBER(10,2),
    Type VARCHAR2(50),
    NumberOfRooms NUMBER,
    BranchID NUMBER
);

CREATE OR REPLACE TYPE ViewingType1 AS OBJECT (
    ViewingID NUMBER,
    PropertyID NUMBER,
    DateTime TIMESTAMP,
    Comments VARCHAR(255)
);

CREATE OR REPLACE TYPE ViewingTableType1 AS TABLE OF ViewingType1;

-- Create tables based on the object types
CREATE TABLE ClientObjectTable1 OF ClientType1;

CREATE TABLE RentalPropertyObjectTable1 OF RentalPropertyType1;

-- Inserting sample data into the object tables
INSERT INTO ClientObjectTable1 VALUES (
    ClientType1(1, 'Alice Johnson', '789 Birch Lane', '555-7890', 'alice.johnson@example.com', DATE '1985-03-10')
);

INSERT INTO ClientObjectTable1 VALUES (
    ClientType1(2, 'Bob Williams', '101 Cedar Road', '555-2345', 'bob.williams@example.com', DATE '1992-08-22')
);

INSERT INTO RentalPropertyObjectTable1 VALUES (
    RentalPropertyType1(201, '202 Oak Avenue', 'Central Park', 'Luxurious 4-bedroom villa', 'Includes swimming pool and garden', 550000, 'Villa', 4, 1)
);

INSERT INTO RentalPropertyObjectTable1 VALUES (
    RentalPropertyType1(202, '303 Maple Street', 'Old Town', 'Charming 2-bedroom cottage', 'Near the city center', 275000, 'Cottage', 2, 1)
);




-- Create a table for property viewings, linking to clients and properties
CREATE TABLE PropertyViewingTable1 (
    ViewingID NUMBER PRIMARY KEY,
    ClientID NUMBER,
    PropertyID NUMBER,
    DateTime TIMESTAMP NOT NULL,
    Comments VARCHAR(200 CHAR),
    FOREIGN KEY (ClientID) REFERENCES ClientNameObjectTable(ClientID),
    FOREIGN KEY (PropertyID) REFERENCES RentalPropertyObjectTable(PropertyID)
);


ALTER TABLE ClientObjectTable1
ADD CONSTRAINT pk_client2 PRIMARY KEY (ClientID);

ALTER TABLE RentalPropertyObjectTable1
ADD CONSTRAINT pk_property2 PRIMARY KEY (PropertyID);


-- Inserting sample viewing data
INSERT INTO PropertyViewingTable1 VALUES (
    301, 1, 201, TIMESTAMP '2024-09-12 11:00:00', 'Impressed with the garden and layout'
);

INSERT INTO PropertyViewingTable1 VALUES (
    302, 2, 202, TIMESTAMP '2024-09-18 15:00:00', 'Liked the location but needs more space'
);



-- Retrieve information about properties viewed by a specific client
SELECT c.ClientID, c.Name, p.PropertyID, p.Address, v.DateTime, v.Comments
FROM ClientNameObjectTable c
JOIN PropertyViewingTable v ON c.ClientID = v.ClientID
JOIN RentalPropertyObjectTable p ON v.PropertyID = p.PropertyID
WHERE c.ClientID = 1;

