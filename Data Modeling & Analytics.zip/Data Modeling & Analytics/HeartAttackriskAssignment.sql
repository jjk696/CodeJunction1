--step1: import CSV file 

select* from heartattackrisk;

--Step-by-Step Process for SQL-Based Data Mining in Oracle

-- Check the structure of the dataset
DESCRIBE heartattackrisk;

-- Get a summary of key features like Age and Cholesterol
SELECT 
    AVG(Age) AS Avg_Age, 
    AVG(Cholesterol) AS Avg_Cholesterol, 
    COUNT(*) AS Total_Patients
FROM 
    heartattackrisk;

-- Check the distribution of Heart Attack Risk (Yes/No)
SELECT Heart_Attack_Risk, COUNT(*) 
FROM heartattackrisk 
GROUP BY Heart_Attack_Risk;

--Split the Dataset for Training and Testing=> Split the dataset into training (70%-80%) and testing (20%-30%) sets using Oracle�s SQL.

-- Add a random number column for splitting
ALTER TABLE heartattackrisk ADD Split_Rand NUMBER;

-- Populate the Split_Rand column with random values
UPDATE heartattackrisk
SET Split_Rand = DBMS_RANDOM.VALUE;

-- Create training set (70% of data)
CREATE TABLE HeartAttackRisk_Train AS
SELECT * FROM heartattackrisk 
WHERE Split_Rand <= 0.7;

-- Create testing set (30% of data)
CREATE TABLE HeartAttackRisk_Test AS
SELECT * FROM heartattackrisk 
WHERE Split_Rand > 0.7;


select * from HeartAttackRisk_Test;
select * from HeartAttackRisk_Train;

--Check Table and Data Availability:
SELECT COUNT(*) FROM HeartAttackRisk_Train;


--Check Oracle Data Mining Setup:
SELECT * FROM DBA_MINING_MODELS;
/

SELECT * FROM ALL_OBJECTS WHERE OBJECT_NAME = 'DBMS_DATA_MINING';

/
--Check if Oracle Data Mining (ODM) is Installed

SELECT * FROM ALL_OBJECTS WHERE OBJECT_NAME = 'DBMS_DATA_MINING';

/
--Check Oracle Version and Edition=>Oracle Data Mining (ODM) is only available in Oracle Enterprise Edition. To check which version and edition you are using:
SELECT * FROM V$VERSION;
SELECT BANNER FROM V$VERSION WHERE BANNER LIKE '%Enterprise%';
/

--Install Oracle Data Mining (if not installed)
--SELECT * FROM V$OPTION WHERE PARAMETER = 'Data Mining';

-- Ensure Proper Privileges
GRANT EXECUTE ON DBMS_DATA_MINING TO sys;

GRANT CREATE MINING MODEL TO sys;

-- Add an auto-generated PatientID column

ALTER TABLE HeartAttackRisk ADD PatientID NUMBER GENERATED ALWAYS AS IDENTITY;


--Set Up the Data Mining Model

-- Split the data into training and testing sets
CREATE TABLE HeartAttackRisk_Train1 AS
SELECT * FROM HeartAttackRisk WHERE PatientID <= 200;

CREATE TABLE HeartAttackRisk_Test1 AS
SELECT * FROM HeartAttackRisk WHERE PatientID > 200;

-- Create settings for Decision Tree classification
BEGIN
   DBMS_DATA_MINING.CREATE_MODEL(
      model_name          => 'HeartAttackRisk_DT_Model',
      mining_function     => DBMS_DATA_MINING.CLASSIFICATION,
      data_table_name     => 'HeartAttackRisk_Train1',
      case_id_column_name => 'PatientID',
      target_column_name  => 'Heart_Attack_Risk',
      settings_table_name => NULL -- Use default settings
   );
END;
/

-- Apply the model to the testing set
BEGIN
   DBMS_DATA_MINING.APPLY(
      model_name        => 'HeartAttackRisk_DT_Model',
      data_table_name   => 'HeartAttackRisk_Test1',
      case_id_column_name => 'PatientID',
      result_table_name => 'HeartAttackRisk_DT_Predictions'
   );
END;
/

-- Evaluate the model by comparing predictions with actual outcomes
SELECT t.PatientID, t.Heart_Attack_Risk AS ActualRisk, p.prediction AS PredictedRisk
FROM HeartAttackRisk_Test1 t
JOIN HeartAttackRisk_DT_Predictions p
ON t.PatientID = p.PatientID;



/*
-- Create a model using Decision Tree for classification
BEGIN 
   DBMS_DATA_MINING.CREATE_MODEL(
      model_name          => 'HeartAttackRisk_DT_Model',
      mining_function     => DBMS_DATA_MINING.CLASSIFICATION,
      data_table_name     => 'HeartAttackRisk_Train',
      case_id_column_name => 'PatientID',
      target_column_name  => 'Heart_Attack_Risk',
      settings_table_name => 'mining_settings_dt'
   );
END;
/

-- Apply the model to the testing set
BEGIN
   DBMS_DATA_MINING.APPLY(
      model_name    => 'HeartAttackRisk_DT_Model',
      data_table_name => 'HeartAttackRisk_Test',
      case_id_column_name => 'PatientID',
      result_table_name => 'HeartAttackRisk_DT_Predictions'
   );
END;
/


-- Create a model using Naive Bayes for classification
BEGIN 
   DBMS_DATA_MINING.CREATE_MODEL(
      model_name          => 'HeartAttackRisk_NB_Model',
      mining_function     => DBMS_DATA_MINING.CLASSIFICATION,
      data_table_name     => 'HeartAttackRisk_Train',
      case_id_column_name => 'PatientID',
      target_column_name  => 'Heart_Attack_Risk',
      settings_table_name => 'mining_settings_nb'
   );
END;
/

-- Apply the Naive Bayes model to the testing set
BEGIN
   DBMS_DATA_MINING.APPLY(
      model_name    => 'HeartAttackRisk_NB_Model',
      data_table_name => 'HeartAttackRisk_Test',
      case_id_column_name => 'PatientID',
      result_table_name => 'HeartAttackRisk_NB_Predictions'
   );
END;
/


-- Compare the predictions of the Decision Tree model with actual outcomes
SELECT 
    COUNT(*) AS Correct_Predictions,
    (SELECT COUNT(*) FROM HeartAttackRisk_Test1) AS Total_Tests
FROM 
    HeartAttackRisk_Test T
JOIN 
    HeartAttackRisk_DT_Predictions P ON T.PatientID = P.PatientID
WHERE 
    T.Heart_Attack_Risk = P.PREDICTION;


-- Evaluate Naive Bayes model similarly
SELECT 
    COUNT(*) AS Correct_Predictions,
    (SELECT COUNT(*) FROM HeartAttackRisk_Test1) AS Total_Tests
FROM 
    HeartAttackRisk_Test1 T
JOIN 
    HeartAttackRisk_NB_Predictions P ON T.PatientID = P.PatientID
WHERE 
    T.Heart_Attac_kRisk = P.PREDICTION;

*/