/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java_jdbc;
import java.sql.*;
public class Jdbc_alter_create_rename_drop {
public static void main(String[] args) {
    try
    {
      Class.forName("com.mysql.jdbc.Driver");
      Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/demo","root","123");
      PreparedStatement ps=con.prepareStatement("select * from demo1");
      boolean rs=ps.execute();
      String query="RENAME TABLE student TO new_student";
      String query1="ALTER TABLE demo1 ADD city VARCHAR(100)";
      String query2="DROP TABLE new_student";
      
      ps.execute(query);
      ps.execute(query1);
      ps.execute(query2);
    }
catch(Exception e)
        {
            System.out.println(e); 
        }
}
}    
